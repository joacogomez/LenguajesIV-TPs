// Variable donde vamos a guardar el Blob que creemos
let miBlob = null;

let resultado = document.getElementById("resultado");

// 1) Crear un Blob de texto
function crearBlob() {
  // Un Blob es un "objeto binario" que puede representar datos como si fueran un archivo
  let texto = "Este es un archivo de texto creado con un Blob.\nMateria: Lenguaje IV - UCASAL";

  miBlob = new Blob([texto], { type: "text/plain" });

  resultado.textContent = "Blob creado correctamente. Tamaño: " + miBlob.size + " bytes";
}

// 2) Descargar el Blob como si fuera un archivo
function descargarBlob() {
  if (miBlob === null) {
    alert("Primero tenés que crear el Blob");
    return;
  }

  // Creamos una URL temporal que apunta al Blob
  let url = URL.createObjectURL(miBlob);

  // Creamos un link invisible y simulamos un clic para que se descargue
  let enlace = document.createElement("a");
  enlace.href = url;
  enlace.download = "archivo.txt";
  enlace.click();

  // Liberamos la URL temporal
  URL.revokeObjectURL(url);

  resultado.textContent = "Archivo descargado como archivo.txt";
}

// 3) Usar slice() para recortar una parte del Blob
function usarSlice() {
  if (miBlob === null) {
    alert("Primero tenés que crear el Blob");
    return;
  }

  // slice(inicio, fin) recorta el Blob, igual que slice() en un array
  let blobRecortado = miBlob.slice(0, 20);

  // Usamos un FileReader para poder leer el contenido recortado como texto
  let lector = new FileReader();

  lector.onload = function (evento) {
    resultado.textContent = "Primeros 20 bytes del Blob:\n" + evento.target.result;
  };

  lector.readAsText(blobRecortado);
}
