function mostrarImagen() {
  // Tomamos el input y el archivo que el usuario eligió
  let input = document.getElementById("inputImagen");
  let archivo = input.files[0];

  // Si no eligió ningún archivo, no hacemos nada
  if (!archivo) {
    return;
  }

  // Elementos donde vamos a mostrar la info y la imagen
  let nombreArchivo = document.getElementById("nombreArchivo");
  let pesoArchivo = document.getElementById("pesoArchivo");
  let vistaPrevia = document.getElementById("vistaPrevia");

  // Mostramos el nombre del archivo y su peso en bytes, cada uno en su línea
  nombreArchivo.textContent = archivo.name;
  pesoArchivo.textContent = archivo.size + " bytes";

  // FileReader nos permite leer el contenido del archivo para poder mostrarlo
  let lector = new FileReader();

  lector.onload = function (evento) {
    vistaPrevia.src = evento.target.result;
    vistaPrevia.style.display = "block";
  };

  lector.readAsDataURL(archivo);
}
